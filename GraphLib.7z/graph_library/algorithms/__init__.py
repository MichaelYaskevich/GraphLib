from src.algorithms import bellman_ford
from src.algorithms import algorithm_for_DAG
from src.algorithms import dijkstra
from src.algorithms import floyd
