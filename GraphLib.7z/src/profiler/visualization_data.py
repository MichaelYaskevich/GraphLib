class VisualizationData:
    def __init__(self, data_dictionaries,
                 points_dictionaries, confidence_intervals):
        self.data_dictionaries = data_dictionaries
        self.points_dictionaries = points_dictionaries
        self.confidence_intervals = confidence_intervals
